Site url: http://george-network-udacitylb-1119153750.us-west-2.elb.amazonaws.com
